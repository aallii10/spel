/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sleutelfun;

/**
 * 
 * @author donna
 */
public class Speler {
    private int sleutelcode; 
    
    //constructor dingen. Gebeuren zodra je het aanmaakt. Bijv meerdere spelers-> kleur die niet veranderd. Dit komt in de constructor. 
    
    public int getSleutelcode () {
        return sleutelcode; 
    }
    
}
