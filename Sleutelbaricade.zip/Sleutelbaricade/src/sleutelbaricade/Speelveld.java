package sleutelbaricade;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class Speelveld extends JPanel implements ActionListener {

    private Timer timer;

    private Level l;
    private Speler s;
    private Pad p ; 
    private Muur m ; 
    private Sleutel sl;
    

    public Speelveld() {
    
        
        l = new Level();
        s = new Speler();
        p = new Pad();
        m = new Muur();
        sl = new Sleutel(5);

        addKeyListener(new Al());
        setFocusable(true);

        timer = new Timer(25, this);
        timer.start();
    }

    public void actionPerformed(ActionEvent e) {
        repaint();
    }

    public void paint(Graphics g) {
        super.paint(g);
        for (int y = 0; y < 10; y++) {
            for (int x = 0; x < 10; x++) {
                if (l.getLevel(x, y).equals("p")) {
                    g.drawImage( p.getPad() , x * 32, y * 32 , null);
                }
                if (l.getLevel(x, y).equals("m")) {
                    g.drawImage(m.getMuur(), x * 32, y * 32, null);
                }
                if (l.getLevel(x, y).equals("1")) {
                    g.drawImage(sl.getSleutel(), x * 32, y * 32, null);
                }
            }
        }
        g.drawImage(s.getSpeler(), s.getPadX() * 32, s.getPadY() * 32, null);
    }

    public class Al extends KeyAdapter {

        public void keyPressed(KeyEvent e) {
            int keycode = e.getKeyCode();

            if (keycode == KeyEvent.VK_W) {
                if (!l.getLevel(s.getPadX(), s.getPadY()-1).equals("m")) {

                    s.bewegen(0, -1);
                }
            }
            if (keycode == KeyEvent.VK_S) {
                if (!l.getLevel(s.getPadX(), s.getPadY()+1).equals("m")) {
                    s.bewegen(0, 1);
                }
            }
            if (keycode == KeyEvent.VK_A) {
                if (!l.getLevel(s.getPadX()-1, s.getPadY()).equals("m")) {

                    s.bewegen(-1, 0);
                }
            }
            if (keycode == KeyEvent.VK_D) {
                if (!l.getLevel(s.getPadX()+1, s.getPadY()).equals("m")) {
                
                s.bewegen(1, 0);
            }
        }
    }
    }
    


}


