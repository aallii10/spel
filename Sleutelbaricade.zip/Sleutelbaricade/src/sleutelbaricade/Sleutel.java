/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sleutelbaricade;

import java.awt.*;
import java.util.*;
import java.io.*;
import javax.swing.*;



public class  Sleutel extends Tegel{
    
    public Image  sleutel;
    private int sleutelcode;
    private boolean sleutelchecker;
    
    public Sleutel(int scode){
     
     ImageIcon img = new ImageIcon("C://Users//Cas//Documents//test//Sleutel.png");
     sleutel = img.getImage();
     
     this.sleutelcode = scode;
     this.sleutelchecker = true; // De sleutel ligt te liggen en er is niks mee gebeurd. 
        
    }
    
public Image getSleutel() {
        return sleutel;
    }

    @Override
    public boolean isBewandelbaar() {
        return true; //To change body of generated methods, choose Tools | Templates.
    }
    
     @Override
    public void bewandelTegel() { //We
        if (sleutelchecker) {
           // speler1.getSleutelcode(sleutelcode);
            sleutelchecker = false;
        }
}
}