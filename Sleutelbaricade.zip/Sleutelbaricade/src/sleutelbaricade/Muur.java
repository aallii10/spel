/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sleutelbaricade;

import java.awt.*;
import java.util.*;
import java.io.*;
import javax.swing.*;


public class Muur extends Tegel {
    
  public Image muur;
    
   public Muur(){
   
        ImageIcon img = new ImageIcon("C://Users//Cas//Documents//test//Muur.png");
        muur = img.getImage();
   }
   
   public Image getMuur() {
        return muur;
    }

    @Override
    public boolean isBewandelbaar() {
        return false; 
    }
    
    
}
