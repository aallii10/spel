/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sleutelbaricade;

import java.awt.*;
import java.util.*;
import java.io.*;
import javax.swing.*;

/**
 *
 * @author Cas
 */
public class Level {

    private Scanner l;
    private String Level[] = new String[10];
    

    public Level() {

        openLevel();
        readLevel();
        closeLevel();

    }

    public String getLevel(int x, int y) {
        String index = Level[y].substring(x, x + 1);
        return index;
    }

    public void openLevel() {
        try {
            l = new Scanner(new File("C://Users//Cas//Documents//test//Level1.txt"));
        } catch (Exception e) {
            System.out.println("error Loading");

        }
    }

    public void readLevel() {
        while (l.hasNext()) {
            for (int i = 0; i < 10; i++) {
                Level[i] = l.next();

            }

        }

    }

    public void closeLevel() {
        l.close();
    }
}
