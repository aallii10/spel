/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sleutelbaricade;

/**
 *
 * @author Cas
 */
public class Barricade extends Tegel {
    
    private int barricadeCode;
    private boolean openBarricade;

    public Barricade(int bcode){
    
     this.barricadeCode = bcode;
     this.openBarricade = false;
    
    }
    
    
    
    
    @Override
    public boolean isBewandelbaar() {
     if (1 == barricadeCode) {
            return true;
        } else if (openBarricade) {
            return true;            
        } else {
            return false;
        } //To change body of generated methods, choose Tools | Templates.
    }
    
    
    @Override
     public void bewandelTegel() { //2.0 toegevoegd
         openBarricade = true; 
     }

    
}
